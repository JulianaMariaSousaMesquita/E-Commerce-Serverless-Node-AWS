const AWS = require('aws-sdk')
const AWSXRay = require('aws-xray-sdk-core')
const uuid = require('uuid')

const xRay = AWSXRay.captureAWS(require('aws-sdk'))

const awsRegion = process.env.AWS_REGION
const invoicesDdb = process.env.INVOICES_DDB
const bucketName = process.env.BUCKET_NAME
const invoiceWsApiEndpoint = process.env.INVOICE_WSAPI_ENDPOINT.substring(6)

AWS.config.update({
   region: awsRegion,
})

const s3 = new AWS.S3({
   region: awsRegion,
})

const ddbClient = new AWS.DynamoDB.DocumentClient()

const apigwManagementApi = new AWS.ApiGatewayManagementApi({
   apiVersion: '2018-11-29',
   endpoint: invoiceWsApiEndpoint,
})

const invoiceTransactionLayer = require('/opt/nodejs/invoiceTransaction')(
   ddbClient,
   invoicesDdb
)

const invoiceWSConnectionLayer = require('/opt/nodejs/invoiceWSConnection')(
   apigwManagementApi
)

exports.handler = async function (event, context) {
   console.log(event)

   const lambdaRequestId = context.awsRequestId
   const connectionId = event.requestContext.connectionId

   console.log(
      `ConnectionId: ${connectionId} - Lambda RequestId: ${lambdaRequestId}`
   )

   const expires = 300

   const key = uuid.v4()
   const params = {
      Bucket: bucketName,
      Key: key,
      Expires: expires,
   }
   const signedUrlPut = await s3.getSignedUrl('putObject', params)

   const postData = JSON.stringify({
      url: signedUrlPut,
      expires: expires,
      transactionId: key,
   })

   await invoiceTransactionLayer.createInvoiceTransaction(
      key,
      lambdaRequestId,
      expires,
      connectionId,
      invoiceWsApiEndpoint
   )

   await invoiceWSConnectionLayer.sendData(connectionId, postData)

   return {}
}
