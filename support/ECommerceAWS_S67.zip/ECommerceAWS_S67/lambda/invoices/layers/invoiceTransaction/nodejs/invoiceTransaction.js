module.exports = function (ddbClient, invoicesDdb) {
   function createInvoiceTransaction(
      key,
      requestId,
      expiresIn,
      connectionId,
      invoiceWsApiEndpoint
   ) {
      const timestamp = Date.now()
      const ttl = ~~(timestamp / 1000 + 60 * 2)

      const params = {
         TableName: invoicesDdb,
         Item: {
            pk: '#transaction',
            sk: key,
            ttl: ttl,
            requestId: requestId,
            transactionStatus: 'URL_GENERATED',
            timestamp: timestamp,
            expiresIn: expiresIn,
            connectionId: connectionId,
            endpoint: invoiceWsApiEndpoint,
         },
      }

      return ddbClient.put(params).promise()
   }

   function updateInvoiceTransaction(key, status) {
      return ddbClient
         .update({
            TableName: invoicesDdb,
            Key: {
               pk: `#transaction`,
               sk: key,
            },
            UpdateExpression: 'set transactionStatus = :s',
            ExpressionAttributeValues: {
               ':s': status,
            },
         })
         .promise()
   }

   function getInvoiceTransaction(key) {
      const params = {
         TableName: invoicesDdb,
         Key: {
            pk: '#transaction',
            sk: key,
         },
      }

      return ddbClient.get(params).promise()
   }

   return {
      createInvoiceTransaction: createInvoiceTransaction,
      updateInvoiceTransaction: updateInvoiceTransaction,
      getInvoiceTransaction: getInvoiceTransaction,
   }
}
