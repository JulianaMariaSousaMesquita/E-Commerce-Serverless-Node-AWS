module.exports = function (apigwManagementApi) {
   async function sendData(connectionId, data) {
      try {
         await apigwManagementApi
            .getConnection({ ConnectionId: connectionId })
            .promise()

         return apigwManagementApi
            .postToConnection({
               ConnectionId: connectionId,
               Data: data,
            })
            .promise()
      } catch (err) {
         console.error(err)
      }
   }

   function sendInvoiceStatus(transactionId, connectionId, status) {
      const postData = JSON.stringify({
         key: transactionId,
         status: status,
      })

      return sendData(connectionId, postData)
   }

   async function disconnectClient(connectionId) {
      try {
         const params = {
            ConnectionId: connectionId,
         }
         await apigwManagementApi
            .getConnection({ ConnectionId: connectionId })
            .promise()

         return apigwManagementApi.deleteConnection(params).promise()
      } catch (err) {
         console.error(err)
      }
   }

   return {
      sendInvoiceStatus: sendInvoiceStatus,
      sendData: sendData,
      disconnectClient: disconnectClient,
   }
}
