const AWS = require('aws-sdk')
const AWSXRay = require('aws-xray-sdk-core')

const xRay = AWSXRay.captureAWS(require('aws-sdk'))

const awsRegion = process.env.AWS_REGION
const invoicesDdb = process.env.INVOICES_DDB
const invoiceWsApiEndpoint = process.env.INVOICE_WSAPI_ENDPOINT.substring(6)
const auditBusName = process.env.AUDIT_BUS_NAME

AWS.config.update({
   region: awsRegion,
})

const ddbClient = new AWS.DynamoDB.DocumentClient()
const s3Client = new AWS.S3()
const apigwManagementApi = new AWS.ApiGatewayManagementApi({
   apiVersion: '2018-11-29',
   endpoint: invoiceWsApiEndpoint,
})
const eventBridgeClient = new AWS.EventBridge()

const invoiceTransactionLayer = require('/opt/nodejs/invoiceTransaction')(
   ddbClient,
   invoicesDdb
)

const invoiceWSConnectionLayer = require('/opt/nodejs/invoiceWSConnection')(
   apigwManagementApi
)

exports.handler = async function (event, context) {
   console.log(event.Records[0].s3)

   const key = event.Records[0].s3.object.key

   const params = {
      Key: key,
      Bucket: event.Records[0].s3.bucket.name,
   }

   const invoiceTransactionResult =
      await invoiceTransactionLayer.getInvoiceTransaction(key)
   const invoiceTransaction = invoiceTransactionResult.Item

   if (invoiceTransaction) {
      if (invoiceTransaction.transactionStatus === 'URL_GENERATED') {
         await Promise.all([
            invoiceWSConnectionLayer.sendInvoiceStatus(
               invoiceTransaction.sk,
               invoiceTransaction.connectionId,
               'INVOICE_RECEIVED'
            ),
            invoiceTransactionLayer.updateInvoiceTransaction(
               key,
               'INVOICE_RECEIVED'
            ),
         ])
      } else {
         await invoiceWSConnectionLayer.sendInvoiceStatus(
            invoiceTransaction.sk,
            invoiceTransaction.connectionId,
            invoiceTransaction.transactionStatus
         )
         console.error(
            `Non valid transaction status: ${invoiceTransaction.transactionStatus}`
         )

         await invoiceWSConnectionLayer.disconnectClient(
            invoiceTransaction.connectionId
         )
         return {}
      }
   }

   const object = await s3Client.getObject(params).promise()

   const invoice = JSON.parse(object.Body.toString('utf-8'))
   console.log(invoice)

   if (invoice.invoiceNumber) {
      const createInvoicePromise = createInvoice(invoice, key)
      const deleteInvoicePromise = s3Client.deleteObject(params).promise()

      if (invoiceTransaction) {
         await Promise.all([
            invoiceWSConnectionLayer.sendInvoiceStatus(
               invoiceTransaction.sk,
               invoiceTransaction.connectionId,
               'INVOICE_PROCESSED'
            ),
            invoiceTransactionLayer.updateInvoiceTransaction(
               key,
               'INVOICE_PROCESSED'
            ),
         ])

         await invoiceWSConnectionLayer.disconnectClient(
            invoiceTransaction.connectionId
         )
      }

      await Promise.all([createInvoicePromise, deleteInvoicePromise])
   } else {
      console.log('Invoice import failed - timeout / error')
      await sendInvoiceStatus(
         apigwManagementApi,
         transactionId,
         connectionId,
         'TIMEOUT'
      )

      await disconnectClient(apigwManagementApi, connectionId)

      const params = {
         Entries: [
            {
               Source: 'app.invoice',
               EventBusName: auditBusName,
               DetailType: 'invoice',
               Time: new Date(),

               Detail: JSON.stringify({
                  errorDetail: 'FAIL_NO_INVOICE_NUMBER',
                  info: {
                     invoiceKey: key,
                     customerName: invoice.customerName,
                  },
               }),
            },
         ],
      }
      const result = await eventBridgeClient.putEvents(params).promise()
      console.log(result)
   }

   return {}
}

function createInvoice(invoice, key) {
   const params = {
      TableName: invoicesDdb,
      Item: {
         pk: `#invoice_${invoice.customerName}`,
         sk: invoice.invoiceNumber,
         totalValue: invoice.totalValue,
         productId: invoice.productId,
         quantity: invoice.quantity,
         transactionId: key,
         ttl: 0,
         createdAt: Date.now(),
      },
   }

   return ddbClient.put(params).promise()
}
