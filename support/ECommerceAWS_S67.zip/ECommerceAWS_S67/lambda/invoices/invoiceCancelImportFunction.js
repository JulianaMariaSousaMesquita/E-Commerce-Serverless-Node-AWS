const AWS = require('aws-sdk')
const AWSXRay = require('aws-xray-sdk-core')

const xRay = AWSXRay.captureAWS(require('aws-sdk'))

const awsRegion = process.env.AWS_REGION
const invoicesDdb = process.env.INVOICES_DDB
const invoiceWsApiEndpoint = process.env.INVOICE_WSAPI_ENDPOINT.substring(6)

AWS.config.update({
   region: awsRegion,
})

const ddbClient = new AWS.DynamoDB.DocumentClient()
const apigwManagementApi = new AWS.ApiGatewayManagementApi({
   apiVersion: '2018-11-29',
   endpoint: invoiceWsApiEndpoint,
})

const invoiceTransactionLayer = require('/opt/nodejs/invoiceTransaction')(
   ddbClient,
   invoicesDdb
)

const invoiceWSConnectionLayer = require('/opt/nodejs/invoiceWSConnection')(
   apigwManagementApi
)

exports.handler = async function (event, context) {
   console.log(event)

   const transactionId = JSON.parse(event.body).transactionId
   const lambdaRequestId = context.awsRequestId
   const connectionId = event.requestContext.connectionId

   console.log(
      `ConnectionId: ${connectionId} - Lambda RequestId: ${lambdaRequestId}`
   )

   const invoiceTransactionResult =
      await invoiceTransactionLayer.getInvoiceTransaction(transactionId)
   const invoiceTransaction = invoiceTransactionResult.Item

   if (invoiceTransaction) {
      if (invoiceTransaction.transactionStatus === 'URL_GENERATED') {
         await Promise.all([
            invoiceWSConnectionLayer.sendInvoiceStatus(
               invoiceTransaction.sk,
               invoiceTransaction.connectionId,
               'INVOICE_CANCELLED'
            ),
            invoiceTransactionLayer.updateInvoiceTransaction(
               transactionId,
               'INVOICE_CANCELLED'
            ),
         ])

         await invoiceWSConnectionLayer.disconnectClient(
            invoiceTransaction.connectionId
         )
      } else {
         await invoiceWSConnectionLayer.sendInvoiceStatus(
            invoiceTransaction.sk,
            invoiceTransaction.connectionId,
            invoiceTransaction.transactionStatus
         )
         console.error("Can't cancel an ongoing process")
      }
   } else {
      console.error(
         `Invoice transaction not found - TransactionId: ${transactionId}`
      )
   }
   return {}
}
