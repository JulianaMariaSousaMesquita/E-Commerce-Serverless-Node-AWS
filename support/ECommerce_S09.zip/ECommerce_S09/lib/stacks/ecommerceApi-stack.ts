import * as cdk from "@aws-cdk/core"
import * as apigateway from "@aws-cdk/aws-apigateway"
import * as cwlogs from "@aws-cdk/aws-logs"
import * as lambdaNodeJS from "@aws-cdk/aws-lambda-nodejs"

interface ECommerceApiStackProps extends cdk.StackProps {
   productsHandler: lambdaNodeJS.NodejsFunction   
}

export class ECommerceApiStack extends cdk.Stack {
   public readonly urlOutput: cdk.CfnOutput;

   constructor(scope: cdk.Construct, id: string, props: ECommerceApiStackProps) {
      super(scope, id, props)

      const logGroup = new cwlogs.LogGroup(this, "ECommerceApiLogs")      
      const api = new apigateway.RestApi(this, "ecommerce-api", {
         restApiName: "ECommerce Service",
         description: "This is the ECommerce service",
         deployOptions: {
            accessLogDestination: new apigateway.LogGroupLogDestination(logGroup),
            accessLogFormat: apigateway.AccessLogFormat.jsonWithStandardFields({
               caller: true,
               httpMethod: true,
               ip: true,
               protocol: true,
               requestTime: true,
               resourcePath: true,
               responseLength: true,
               status: true,
               user: true               
            })
         }
      })

      const productsFunctionIntegration = new apigateway.LambdaIntegration(props.productsHandler)

      // /products
      const productsResource = api.root.addResource("products");
      
      //GET /products
      productsResource.addMethod("GET", productsFunctionIntegration)
      //POST /products
      productsResource.addMethod("POST", productsFunctionIntegration)

      // /products/{id}
      const productIdResource = productsResource.addResource("{id}")

      //GET /products/{id}
      productIdResource.addMethod("GET", productsFunctionIntegration)

      //PUT /products/{id}
      productIdResource.addMethod("PUT", productsFunctionIntegration)

      //DELETE /products/{id}      
      productIdResource.addMethod("DELETE", productsFunctionIntegration)




      this.urlOutput = new cdk.CfnOutput(this, "url", {
         exportName: "url",
         value: api.url
      })
   }
}