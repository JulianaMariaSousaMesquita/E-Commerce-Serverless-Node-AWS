const AWS = require("aws-sdk")
const AWSXRay = require("aws-xray-sdk-core")
const uuid = require("uuid")

const productsDdb = process.env.PRODUCTS_DDB
const awsRegion = process.env.AWS_REGION

const xray = AWSXRay.captureAWS(require("aws-sdk"))


AWS.config.update({
   region: awsRegion
})

const ddbClient = new AWS.DynamoDB.DocumentClient()

exports.handler = async function (event, context) {
   const method = event.httpMethod;
   console.log(event)

   const apiRequestId = event.requestContext.requestId;
   const lambdaRequestId = context.awsRequestId;

   console.log(`API Gateway RequestId: ${apiRequestId} - Lambda RequestId: ${lambdaRequestId}`)

   // /products
   if(event.resource === '/products') {
      if (method === 'GET') {
         const data = await getAllProducts()
         return {
            statusCode: 200,
            body: JSON.stringify(data.Items)
         }         
      } else if (method === 'POST') {
         const product =  JSON.parse(event.body)
         product.id = uuid.v4()

         await createProduct(product)

         return {
            statusCode: 201,
            body: JSON.stringify(product)                        
         }
      }
   } else if(event.resource === '/products/{id}') {
      const productId = event.pathParameters.id
      if (method === 'GET') {
         const data = await getProductById(productId)
         if (data.Item) {
            return {
               statusCode: 200,
               body: JSON.stringify(data.Item)   
            }
         } else {
            return {
               statusCode: 404,
               body: JSON.stringify(`Product with ID ${productId} not found`)   
            }
         }
      } else if (method === 'PUT') {
         const data = await getProductById(productId)
         if (data.Item) {
            const product = JSON.parse(event.body)
            await updateProduct(productId, product)

            return {
               statusCode: 200,
               body: JSON.stringify(product)
            }
         } else {
            return {
               statusCode: 404,
               body: JSON.stringify(`Product with ID ${productId} not found`)   
            }
         }
      } else if (method === 'DELETE') {
         const data = await getProductById(productId)
         if (data.Item) {
            await deleteProduct(productId)

            return {
               statusCode: 200,
               body: JSON.stringify(data.Item)
            }
         } else {
            return {
               statusCode: 404,
               body: JSON.stringify(`Product with ID ${productId} not found`)   
            }
         }
      }
   }

   return {
      statusCode: 400,
      body: JSON.stringify({
         message: "Bad request",
         apiGwRequestId: apiRequestId,
         lambdaRequestId: lambdaRequestId
      })
   }
}

function getAllProducts() {
   const params = {
      TableName: productsDdb
   }
   return ddbClient.scan(params).promise()
}

function getProductById(productId) {
   const params = {
      TableName: productsDdb,
      Key: {
         id: productId
      }
   }
   return ddbClient.get(params).promise()
}

function createProduct(product) {
   const params = {
      TableName: productsDdb,
      Item: {
         id: product.id,
         productName: product.productName,
         code: product.code,
         price: product.price,
         model: product.model,
         productUrl: product.productUrl 
      }
   }
   return ddbClient.put(params).promise()
}

function updateProduct(productId, product) {
   const params = {
      TableName: productsDdb,
      Key: {
         id: productId
      },
      UpdateExpression: "set productName = :n, code = :c, price = :p, model = :m, productUrl = :u",
      ExpressionAttributeValues: {
         ":n": product.productName,
         ":c": product.code,
         ":p": product.price,
         ":m": product.model,
         ":u": product.productUrl
      },
      ReturnValues: "UPDATED_NEW"
   }
   return ddbClient.update(params).promise()
}

function deleteProduct(productId) {
   const params = {
      TableName: productsDdb,
      Key: {
         id: productId
      }
   }
   return ddbClient.delete(params).promise()
}